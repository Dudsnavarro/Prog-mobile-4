enum TipoTransacao {
  debito,
  credito;
}